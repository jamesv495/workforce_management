-- Workforce Management System
-- Complete XAMPP / MySQL / MariaDB database
-- Tested for MySQL/MariaDB syntax used by the supplied PHP APIs.

SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';
SET time_zone = '+08:00';

CREATE DATABASE IF NOT EXISTS workforce_management
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE workforce_management;

SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS manager_notification_reads;
DROP TABLE IF EXISTS kiosk_log_entries;
DROP TABLE IF EXISTS overtime_requests;
DROP TABLE IF EXISTS timesheet_review_history;
DROP TABLE IF EXISTS timesheet_reviews;
DROP TABLE IF EXISTS shift_requests;
DROP TABLE IF EXISTS attendance_corrections;
DROP TABLE IF EXISTS employee_leave_balances;
DROP TABLE IF EXISTS leave_requests;
DROP TABLE IF EXISTS schedules;
DROP TABLE IF EXISTS attendance_records;
DROP TABLE IF EXISTS rfid_cards;
DROP TABLE IF EXISTS trusted_devices;
DROP TABLE IF EXISTS otp_challenges;
DROP TABLE IF EXISTS accounts;
DROP TABLE IF EXISTS employees;

SET FOREIGN_KEY_CHECKS = 1;

CREATE TABLE employees (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    employee_id VARCHAR(50) NOT NULL,
    first_name VARCHAR(80) NOT NULL,
    middle_name VARCHAR(80) NULL,
    last_name VARCHAR(80) NOT NULL,
    avatar_url VARCHAR(255) NULL,
    date_of_birth DATE NULL,
    gender VARCHAR(30) NULL,
    address TEXT NULL,
    phone VARCHAR(50) NULL,
    email VARCHAR(190) NULL,
    department_name VARCHAR(100) NULL,
    position_name VARCHAR(120) NULL,
    hire_date DATE NULL,
    employment_type VARCHAR(50) NOT NULL DEFAULT 'REGULAR',
    employment_status VARCHAR(30) NOT NULL DEFAULT 'active',
    manager_id BIGINT UNSIGNED NULL,
    emergency_name VARCHAR(160) NULL,
    emergency_relationship VARCHAR(80) NULL,
    emergency_phone VARCHAR(50) NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_employees_employee_id (employee_id),
    UNIQUE KEY uq_employees_email (email),
    KEY idx_employees_manager (manager_id),
    KEY idx_employees_department (department_name),
    KEY idx_employees_status (employment_status),
    CONSTRAINT fk_employee_manager
        FOREIGN KEY (manager_id) REFERENCES employees(id)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE accounts (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    employee_id VARCHAR(50) NULL,
    email VARCHAR(190) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role VARCHAR(30) NOT NULL DEFAULT 'employee',
    status VARCHAR(30) NOT NULL DEFAULT 'active',
    last_login_at DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_accounts_email (email),
    UNIQUE KEY uq_accounts_employee (employee_id),
    KEY idx_accounts_role_status (role, status),
    CONSTRAINT fk_account_employee
        FOREIGN KEY (employee_id) REFERENCES employees(employee_id)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE otp_challenges (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    account_id BIGINT UNSIGNED NOT NULL,
    code_hash VARCHAR(255) NOT NULL,
    expires_at DATETIME NOT NULL,
    attempts INT UNSIGNED NOT NULL DEFAULT 0,
    consumed_at DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_otp_account (account_id),
    KEY idx_otp_expiry (expires_at),
    CONSTRAINT fk_otp_account
        FOREIGN KEY (account_id) REFERENCES accounts(id)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE trusted_devices (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    account_id BIGINT UNSIGNED NOT NULL,
    device_token_hash CHAR(64) NOT NULL,
    expires_at DATETIME NOT NULL,
    last_used_at DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_trusted_device_hash (device_token_hash),
    KEY idx_trusted_account (account_id),
    CONSTRAINT fk_trusted_account
        FOREIGN KEY (account_id) REFERENCES accounts(id)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE rfid_cards (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    employee_id VARCHAR(50) NOT NULL,
    rfid_uid VARCHAR(100) NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'active',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_rfid_uid (rfid_uid),
    KEY idx_rfid_employee (employee_id),
    CONSTRAINT fk_rfid_employee
        FOREIGN KEY (employee_id) REFERENCES employees(employee_id)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE attendance_records (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    employee_id VARCHAR(50) NOT NULL,
    attendance_date DATE NOT NULL,
    time_in DATETIME NULL,
    time_out DATETIME NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'present',
    source VARCHAR(30) NOT NULL DEFAULT 'manual',
    notes TEXT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_attendance_employee_date (employee_id, attendance_date),
    KEY idx_attendance_date (attendance_date),
    KEY idx_attendance_status (status),
    CONSTRAINT fk_attendance_employee
        FOREIGN KEY (employee_id) REFERENCES employees(employee_id)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE schedules (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    employee_id VARCHAR(50) NOT NULL,
    schedule_date DATE NOT NULL,
    shift_name VARCHAR(100) NOT NULL,
    start_time TIME NULL,
    end_time TIME NULL,
    work_type VARCHAR(50) NOT NULL DEFAULT 'Regular',
    remarks TEXT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'scheduled',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_schedule_employee_date (employee_id, schedule_date),
    KEY idx_schedule_date (schedule_date),
    CONSTRAINT fk_schedule_employee
        FOREIGN KEY (employee_id) REFERENCES employees(employee_id)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE leave_requests (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    employee_id VARCHAR(50) NOT NULL,
    leave_type VARCHAR(100) NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    reason TEXT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'pending',
    approved_by BIGINT UNSIGNED NULL,
    approved_at DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_leave_employee (employee_id),
    KEY idx_leave_status (status),
    KEY idx_leave_dates (start_date, end_date),
    KEY idx_leave_approver (approved_by),
    CONSTRAINT fk_leave_employee
        FOREIGN KEY (employee_id) REFERENCES employees(employee_id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_leave_approver
        FOREIGN KEY (approved_by) REFERENCES accounts(id)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE employee_leave_balances (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    employee_id VARCHAR(50) NOT NULL,
    balance_year YEAR NOT NULL,
    vacation_days DECIMAL(6,2) NOT NULL DEFAULT 15.00,
    sick_days DECIMAL(6,2) NOT NULL DEFAULT 10.00,
    emergency_days DECIMAL(6,2) NOT NULL DEFAULT 5.00,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_leave_balance_employee_year (employee_id, balance_year),
    CONSTRAINT fk_leave_balance_employee
        FOREIGN KEY (employee_id) REFERENCES employees(employee_id)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE attendance_corrections (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    employee_id VARCHAR(50) NOT NULL,
    attendance_record_id BIGINT UNSIGNED NULL,
    correction_date DATE NOT NULL,
    requested_clock_in DATETIME NULL,
    requested_clock_out DATETIME NULL,
    reason TEXT NOT NULL,
    attachment VARCHAR(255) NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'pending',
    reviewed_by BIGINT UNSIGNED NULL,
    reviewed_at DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_correction_employee (employee_id),
    KEY idx_correction_record (attendance_record_id),
    KEY idx_correction_status (status),
    CONSTRAINT fk_correction_employee
        FOREIGN KEY (employee_id) REFERENCES employees(employee_id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_correction_attendance
        FOREIGN KEY (attendance_record_id) REFERENCES attendance_records(id)
        ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT fk_correction_reviewer
        FOREIGN KEY (reviewed_by) REFERENCES accounts(id)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE shift_requests (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    employee_id VARCHAR(50) NOT NULL,
    requested_date DATE NOT NULL,
    requested_shift VARCHAR(120) NOT NULL,
    reason TEXT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'pending',
    reviewed_by BIGINT UNSIGNED NULL,
    reviewed_at DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_shift_request_employee (employee_id),
    KEY idx_shift_request_date (requested_date),
    KEY idx_shift_request_status (status),
    CONSTRAINT fk_shift_request_employee
        FOREIGN KEY (employee_id) REFERENCES employees(employee_id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_shift_request_reviewer
        FOREIGN KEY (reviewed_by) REFERENCES accounts(id)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE timesheet_reviews (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    employee_id VARCHAR(50) NOT NULL,
    period_start DATE NOT NULL,
    period_end DATE NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'pending',
    reviewed_by BIGINT UNSIGNED NULL,
    reviewed_at DATETIME NULL,
    remarks TEXT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_timesheet_employee_period (employee_id, period_start, period_end),
    KEY idx_timesheet_status (status),
    CONSTRAINT fk_timesheet_employee
        FOREIGN KEY (employee_id) REFERENCES employees(employee_id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_timesheet_reviewer
        FOREIGN KEY (reviewed_by) REFERENCES accounts(id)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE timesheet_review_history (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    timesheet_review_id BIGINT UNSIGNED NOT NULL,
    employee_id VARCHAR(50) NOT NULL,
    period_start DATE NOT NULL,
    period_end DATE NOT NULL,
    previous_status VARCHAR(30) NULL,
    new_status VARCHAR(30) NOT NULL,
    action VARCHAR(120) NOT NULL,
    reviewed_by BIGINT UNSIGNED NULL,
    reason TEXT NULL,
    reviewed_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_history_review (timesheet_review_id),
    KEY idx_history_employee (employee_id),
    CONSTRAINT fk_history_review
        FOREIGN KEY (timesheet_review_id) REFERENCES timesheet_reviews(id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_history_employee
        FOREIGN KEY (employee_id) REFERENCES employees(employee_id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_history_reviewer
        FOREIGN KEY (reviewed_by) REFERENCES accounts(id)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE overtime_requests (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    employee_id VARCHAR(50) NOT NULL,
    attendance_record_id BIGINT UNSIGNED NULL,
    overtime_date DATE NOT NULL,
    overtime_hours DECIMAL(6,2) NOT NULL DEFAULT 0.00,
    reason TEXT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'pending',
    reviewed_by BIGINT UNSIGNED NULL,
    reviewed_at DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_overtime_employee (employee_id),
    KEY idx_overtime_date (overtime_date),
    KEY idx_overtime_status (status),
    CONSTRAINT fk_overtime_employee
        FOREIGN KEY (employee_id) REFERENCES employees(employee_id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_overtime_attendance
        FOREIGN KEY (attendance_record_id) REFERENCES attendance_records(id)
        ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT fk_overtime_reviewer
        FOREIGN KEY (reviewed_by) REFERENCES accounts(id)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE kiosk_log_entries (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    employee_id VARCHAR(50) NOT NULL,
    rfid_card_id BIGINT UNSIGNED NOT NULL,
    rfid_uid VARCHAR(100) NOT NULL,
    kiosk_name VARCHAR(120) NOT NULL DEFAULT 'Main Kiosk',
    scan_status VARCHAR(30) NOT NULL DEFAULT 'success',
    scanned_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_kiosk_employee (employee_id),
    KEY idx_kiosk_scanned_at (scanned_at),
    CONSTRAINT fk_kiosk_employee
        FOREIGN KEY (employee_id) REFERENCES employees(employee_id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_kiosk_rfid
        FOREIGN KEY (rfid_card_id) REFERENCES rfid_cards(id)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE manager_notification_reads (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    manager_id BIGINT UNSIGNED NOT NULL,
    notification_type VARCHAR(30) NOT NULL,
    read_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_manager_notification (manager_id, notification_type),
    CONSTRAINT fk_notification_manager
        FOREIGN KEY (manager_id) REFERENCES employees(id)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
-- Demo accounts
-- Passwords:
--   admin@holidaytravels.com     / Admin@123
--   manager@holidaytravels.com   / Manager@123
--   employee@holidaytravels.com  / Employee@123
-- ---------------------------------------------------------------------------

INSERT INTO employees
    (employee_id, first_name, middle_name, last_name, email, phone,
     department_name, position_name, hire_date, employment_type, employment_status,
     address, emergency_name, emergency_relationship, emergency_phone)
VALUES
    ('26011002', 'Maria', NULL, 'Santos',
     'manager@holidaytravels.com', '09171234567',
     'Operations', 'Operations Manager', '2024-01-15',
     'REGULAR', 'active', 'Quezon City',
     'Ana Santos', 'Sibling', '09181234567'),

    ('26011003', 'Elena', NULL, 'Rostova',
     'employee@holidaytravels.com', '09182345678',
     'Operations', 'Tour Guide', '2025-02-10',
     'REGULAR', 'active', 'Quezon City',
     'Liza Rostova', 'Mother', '09192345678'),

    ('26011004', 'David', NULL, 'Kim',
     'david.kim@holidaytravels.com', '09183456789',
     'Operations', 'Tour Guide', '2025-03-05',
     'REGULAR', 'active', 'Makati',
     'Grace Kim', 'Mother', '09193456789'),

    ('26011005', 'Mateo', NULL, 'Rossi',
     'mateo.rossi@holidaytravels.com', '09184567890',
     'Guest Services', 'Front Desk', '2025-04-21',
     'REGULAR', 'active', 'Pasig',
     'Sofia Rossi', 'Sibling', '09194567890'),

    ('26011006', 'Sofia', NULL, 'Alvarez',
     'sofia.alvarez@holidaytravels.com', '09185678901',
     'Guest Services', 'Front Desk', '2025-05-12',
     'REGULAR', 'active', 'Quezon City',
     'Ramon Alvarez', 'Father', '09195678901'),

    ('26011007', 'James', NULL, 'Chen',
     'james.chen@holidaytravels.com', '09186789012',
     'Operations', 'Tour Guide', '2025-06-02',
     'REGULAR', 'active', 'Manila',
     'Mina Chen', 'Mother', '09196789012');

UPDATE employees
SET manager_id = (
    SELECT id FROM (
        SELECT id FROM employees WHERE employee_id = '26011002'
    ) AS manager_lookup
)
WHERE employee_id IN ('26011003','26011004','26011005','26011006','26011007');

INSERT INTO accounts (employee_id, email, password_hash, role, status)
VALUES
    (NULL, 'admin@holidaytravels.com',
     '$2y$12$S7Ya5f/JYqc8r06N0aJTSeriVYQ9Os0d.aV3bnVpf8J0J4TpCdN4C',
     'admin', 'active'),

    ('26011002', 'manager@holidaytravels.com',
     '$2y$12$8hwnsDgZjF0qH0gyWualNePBLTIaupk.2b2nxxDREVg46eiCLjXTK',
     'manager', 'active'),

    ('26011003', 'employee@holidaytravels.com',
     '$2y$12$j2zZCrWtTnDLyYy.TlwU1uarDHX1RpZo.JN4U6.6CCWYb12ltFvMm',
     'employee', 'active'),

    ('26011004', 'david.kim@holidaytravels.com',
     '$2y$12$j2zZCrWtTnDLyYy.TlwU1uarDHX1RpZo.JN4U6.6CCWYb12ltFvMm',
     'employee', 'active'),

    ('26011005', 'mateo.rossi@holidaytravels.com',
     '$2y$12$j2zZCrWtTnDLyYy.TlwU1uarDHX1RpZo.JN4U6.6CCWYb12ltFvMm',
     'employee', 'active'),

    ('26011006', 'sofia.alvarez@holidaytravels.com',
     '$2y$12$j2zZCrWtTnDLyYy.TlwU1uarDHX1RpZo.JN4U6.6CCWYb12ltFvMm',
     'employee', 'active'),

    ('26011007', 'james.chen@holidaytravels.com',
     '$2y$12$j2zZCrWtTnDLyYy.TlwU1uarDHX1RpZo.JN4U6.6CCWYb12ltFvMm',
     'employee', 'active');

-- RFID demo cards
INSERT INTO rfid_cards (employee_id, rfid_uid, status)
VALUES
    ('26011003', 'WFM-DEMO-26011003', 'active'),
    ('26011004', 'WFM-DEMO-26011004', 'active');

-- Current-year leave balances
INSERT INTO employee_leave_balances
    (employee_id, balance_year, vacation_days, sick_days, emergency_days)
SELECT employee_id, YEAR(CURDATE()), 15.00, 10.00, 5.00
FROM employees
WHERE employee_id <> '26011002';

-- Schedules for the current Monday-Friday window and next week.
-- These are generated dynamically from the date on which the SQL is imported.
INSERT INTO schedules
    (employee_id, schedule_date, shift_name, start_time, end_time, work_type, remarks, status)
SELECT e.employee_id,
       DATE_ADD(DATE_SUB(CURDATE(), INTERVAL WEEKDAY(CURDATE()) DAY), INTERVAL d.n DAY),
       CASE
           WHEN MOD(d.n, 2) = 0 THEN 'Morning Shift'
           ELSE 'Regular Shift'
       END,
       CASE
           WHEN MOD(d.n, 2) = 0 THEN '08:00:00'
           ELSE '09:00:00'
       END,
       CASE
           WHEN MOD(d.n, 2) = 0 THEN '17:00:00'
           ELSE '18:00:00'
       END,
       'Regular',
       'Demo schedule imported for XAMPP testing.',
       'scheduled'
FROM employees e
CROSS JOIN (
    SELECT 0 n UNION ALL SELECT 1 UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4
    UNION ALL SELECT 7 UNION ALL SELECT 8 UNION ALL SELECT 9 UNION ALL SELECT 10 UNION ALL SELECT 11
) d
WHERE e.employee_id IN ('26011003','26011004','26011005','26011006','26011007');

-- Today's attendance for a few employees.
INSERT INTO attendance_records
    (employee_id, attendance_date, time_in, time_out, status, source, notes)
VALUES
    ('26011004', CURDATE(), DATE_ADD(CURDATE(), INTERVAL 9 HOUR), NULL,
     'present', 'manual', 'Demo employee currently clocked in.'),
    ('26011005', CURDATE(), NULL, NULL,
     'absent', 'manual', 'Demo absent status.');

-- Sample historical attendance for analytics and timesheets.
INSERT INTO attendance_records
    (employee_id, attendance_date, time_in, time_out, status, source, notes)
VALUES
    ('26011003', DATE_SUB(CURDATE(), INTERVAL 1 DAY),
     TIMESTAMP(DATE_SUB(CURDATE(), INTERVAL 1 DAY), '08:00:00'),
     TIMESTAMP(DATE_SUB(CURDATE(), INTERVAL 1 DAY), '17:00:00'),
     'present', 'manual', 'Demo historical attendance.'),
    ('26011003', DATE_SUB(CURDATE(), INTERVAL 2 DAY),
     TIMESTAMP(DATE_SUB(CURDATE(), INTERVAL 2 DAY), '08:12:00'),
     TIMESTAMP(DATE_SUB(CURDATE(), INTERVAL 2 DAY), '17:20:00'),
     'late', 'manual', 'Demo late attendance.'),
    ('26011004', DATE_SUB(CURDATE(), INTERVAL 1 DAY),
     TIMESTAMP(DATE_SUB(CURDATE(), INTERVAL 1 DAY), '08:05:00'),
     TIMESTAMP(DATE_SUB(CURDATE(), INTERVAL 1 DAY), '17:00:00'),
     'late', 'manual', 'Demo late attendance.'),
    ('26011005', DATE_SUB(CURDATE(), INTERVAL 1 DAY),
     TIMESTAMP(DATE_SUB(CURDATE(), INTERVAL 1 DAY), '09:00:00'),
     TIMESTAMP(DATE_SUB(CURDATE(), INTERVAL 1 DAY), '18:00:00'),
     'present', 'manual', 'Demo historical attendance.');

-- Leave examples. These are future dates so they do not block today's clock-in.
INSERT INTO leave_requests
    (employee_id, leave_type, start_date, end_date, reason, status)
VALUES
    ('26011003', 'Vacation Leave',
     DATE_ADD(CURDATE(), INTERVAL 3 DAY),
     DATE_ADD(CURDATE(), INTERVAL 5 DAY),
     'Family trip demo request.', 'pending'),
    ('26011004', 'Sick Leave',
     DATE_ADD(CURDATE(), INTERVAL 10 DAY),
     DATE_ADD(CURDATE(), INTERVAL 11 DAY),
     'Medical rest demo request.', 'approved');

-- A manager leave entry for the critical-alert module.
INSERT INTO leave_requests
    (employee_id, leave_type, start_date, end_date, reason, status)
VALUES
    ('26011002', 'Sick Leave',
     DATE_ADD(CURDATE(), INTERVAL 2 DAY),
     DATE_ADD(CURDATE(), INTERVAL 3 DAY),
     'Manager leave demo.', 'approved');

UPDATE leave_requests
SET approved_by = (SELECT id FROM accounts WHERE email = 'admin@holidaytravels.com'),
    approved_at = NOW()
WHERE employee_id = '26011004'
  AND status = 'approved';

UPDATE leave_requests
SET approved_by = (SELECT id FROM accounts WHERE email = 'admin@holidaytravels.com'),
    approved_at = NOW()
WHERE employee_id = '26011002'
  AND status = 'approved';

-- Manager shift-request example.
INSERT INTO shift_requests
    (employee_id, requested_date, requested_shift, reason, status)
VALUES
    ('26011003',
     DATE_ADD(CURDATE(), INTERVAL 6 DAY),
     '10:00 AM - 7:00 PM',
     'Personal schedule adjustment demo request.',
     'pending');

-- Timesheet review examples for current calendar week.
INSERT INTO timesheet_reviews
    (employee_id, period_start, period_end, status, remarks)
SELECT employee_id,
       DATE_SUB(CURDATE(), INTERVAL WEEKDAY(CURDATE()) DAY),
       DATE_ADD(DATE_SUB(CURDATE(), INTERVAL WEEKDAY(CURDATE()) DAY), INTERVAL 6 DAY),
       'pending',
       'Demo timesheet awaiting admin approval.'
FROM employees
WHERE employee_id IN ('26011003','26011004','26011005','26011006','26011007');

-- Sample timesheet history for one employee.
INSERT INTO timesheet_review_history
    (timesheet_review_id, employee_id, period_start, period_end,
     previous_status, new_status, action, reviewed_by, reason)
SELECT tr.id, tr.employee_id, tr.period_start, tr.period_end,
       NULL, 'Pending', 'Timesheet Submitted',
       NULL, 'Initial demo submission.'
FROM timesheet_reviews tr
WHERE tr.employee_id = '26011003'
ORDER BY tr.id DESC
LIMIT 1;

-- Overtime examples.
INSERT INTO overtime_requests
    (employee_id, attendance_record_id, overtime_date, overtime_hours, reason, status)
SELECT '26011003', ar.id, CURDATE(), 2.00,
       'Extended tour support demo request.', 'pending'
FROM attendance_records ar
WHERE ar.employee_id = '26011003'
  AND ar.attendance_date = CURDATE()
LIMIT 1;

INSERT INTO overtime_requests
    (employee_id, attendance_record_id, overtime_date, overtime_hours, reason, status)
SELECT '26011004', ar.id, DATE_SUB(CURDATE(), INTERVAL 1 DAY), 1.50,
       'Completed late client transfer.', 'approved'
FROM attendance_records ar
WHERE ar.employee_id = '26011004'
  AND ar.attendance_date = DATE_SUB(CURDATE(), INTERVAL 1 DAY)
LIMIT 1;

-- Kiosk log demo entry.
INSERT INTO kiosk_log_entries
    (employee_id, rfid_card_id, rfid_uid, kiosk_name, scan_status, scanned_at)
SELECT '26011003', r.id, r.rfid_uid, 'Main Kiosk', 'success', NOW()
FROM rfid_cards r
WHERE r.employee_id = '26011003'
LIMIT 1;

-- Helpful view for admins / reports.
CREATE OR REPLACE VIEW v_employee_directory AS
SELECT
    e.employee_id,
    CONCAT_WS(' ', e.first_name, e.middle_name, e.last_name) AS employee_name,
    e.email,
    e.phone,
    e.department_name,
    e.position_name,
    e.hire_date,
    e.employment_type,
    e.employment_status,
    e.manager_id,
    a.role AS account_role,
    a.status AS account_status
FROM employees e
LEFT JOIN accounts a ON a.employee_id = e.employee_id;

