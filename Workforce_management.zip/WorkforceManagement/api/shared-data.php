<?php
declare(strict_types=1);

require_once __DIR__ . '/auth/session_guard.php';
require_once __DIR__ . '/config/database.php';

header('Content-Type: application/json; charset=utf-8');

$user = requireLogin();

function sharedResponse(bool $success, $data = null, string $message = '', int $status = 200): never
{
    http_response_code($status);
    echo json_encode([
        'success' => $success,
        'data' => $data,
        'message' => $message
    ], JSON_UNESCAPED_SLASHES);
    exit;
}

function formatLegacyTime(?string $dateTime): ?string
{
    if (!$dateTime) {
        return null;
    }

    $ts = strtotime($dateTime);

    return $ts === false ? null : date('H:i', $ts);
}

function normalizeStatusLabel(string $status): string
{
    $status = strtolower(trim($status));

    return match ($status) {
        'present' => 'Present',
        'late' => 'Late',
        'absent' => 'Absent',
        'leave', 'on_leave' => 'On Leave',
        default => ucfirst(str_replace('_', ' ', $status))
    };
}

try {
    $collection = trim((string)($_GET['collection'] ?? ''));

    if ($collection === '') {
        sharedResponse(false, null, 'Collection is required.', 400);
    }

    switch ($collection) {

        case 'employees':
            $stmt = $pdo->query("
                SELECT
                    e.id,
                    e.employee_id,
                    e.first_name,
                    e.middle_name,
                    e.last_name,
                    e.email,
                    e.position_name,
                    e.department_name,
                    e.manager_id,
                    m.employee_id AS manager_employee_id,
                    e.employment_status,
                    COALESCE(a.role, 'employee') AS account_role
                FROM employees e
                LEFT JOIN employees m
                    ON m.id = e.manager_id
                LEFT JOIN accounts a
                    ON a.employee_id = e.employee_id
                WHERE e.employment_status <> 'terminated'
                ORDER BY e.employee_id ASC
            ");

            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
            $data = [];

            foreach ($rows as $row) {
                $role = strtolower((string)$row['account_role']);

                $data[] = [
                    'id' => (string)$row['employee_id'],
                    'name' => trim(
                        ($row['first_name'] ?? '') . ' ' .
                        ($row['middle_name'] ?? '') . ' ' .
                        ($row['last_name'] ?? '')
                    ),
                    'email' => (string)($row['email'] ?? ''),
                    'role' => $role,
                    'position' => (string)($row['position_name'] ?? ''),
                    'department' => (string)($row['department_name'] ?? ''),
                    'managerId' => $row['manager_employee_id'] !== null
                        ? (string)$row['manager_employee_id']
                        : null,
                    'initials' =>
                        strtoupper(
                            substr((string)($row['first_name'] ?? ''), 0, 1) .
                            substr((string)($row['last_name'] ?? ''), 0, 1)
                        ),
                    'status' =>
                        strtoupper((string)$row['employment_status'])
                ];
            }

            sharedResponse(true, $data);

        case 'attendanceRecords':
            $stmt = $pdo->query("
                SELECT
                    a.id,
                    a.employee_id,
                    a.attendance_date,
                    a.time_in,
                    a.time_out,
                    a.status,
                    s.start_time,
                    s.end_time
                FROM attendance_records a
                LEFT JOIN schedules s
                    ON s.employee_id = a.employee_id
                    AND s.schedule_date = a.attendance_date
                    AND s.status <> 'cancelled'
                WHERE a.attendance_date >= DATE_SUB(CURDATE(), INTERVAL 60 DAY)
                ORDER BY a.attendance_date DESC, a.id DESC
            ");

            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
            $data = [];

            foreach ($rows as $row) {
                $schedule = null;

                if ($row['start_time'] !== null && $row['end_time'] !== null) {
                    $schedule =
                        substr((string)$row['start_time'], 0, 5) .
                        '-' .
                        substr((string)$row['end_time'], 0, 5);
                }

                $data[] = [
                    'id' => (int)$row['id'],
                    'employeeId' => (string)$row['employee_id'],
                    'date' => (string)$row['attendance_date'],
                    'schedule' => $schedule,
                    'clockIn' => formatLegacyTime($row['time_in']),
                    'clockOut' => formatLegacyTime($row['time_out']),
                    'status' => normalizeStatusLabel((string)$row['status'])
                ];
            }

            sharedResponse(true, $data);

        case 'leaveRequests':
            $stmt = $pdo->query("
                SELECT
                    lr.id,
                    lr.employee_id,
                    lr.leave_type,
                    lr.start_date,
                    lr.end_date,
                    lr.reason,
                    lr.status,
                    CONCAT_WS(
                        ' ',
                        e.first_name,
                        e.middle_name,
                        e.last_name
                    ) AS employee_name
                FROM leave_requests lr
                INNER JOIN employees e
                    ON e.employee_id = lr.employee_id
                ORDER BY lr.created_at DESC, lr.id DESC
            ");

            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
            $data = [];

            foreach ($rows as $row) {
                $name = trim((string)$row['employee_name']);
                $nameParts = preg_split('/\s+/', $name, -1, PREG_SPLIT_NO_EMPTY);
                $firstInitial = $nameParts[0][0] ?? '';
                $lastInitial = $nameParts[count($nameParts) - 1][0] ?? '';
                $initials = strtoupper($firstInitial . $lastInitial);

                $start = date('M d', strtotime((string)$row['start_date']));
                $end = date('M d', strtotime((string)$row['end_date']));
                $dates = $start === $end ? $start : "{$start} - {$end}";

                $data[] = [
                    'id' => (int)$row['id'],
                    'employeeId' => (string)$row['employee_id'],
                    'name' => $name,
                    'initials' => $initials,
                    'color' => '#6FA9E6',
                    'type' => (string)$row['leave_type'],
                    'status' => ucfirst((string)$row['status']),
                    'dates' => $dates,
                    'reason' => (string)($row['reason'] ?? '')
                ];
            }

            sharedResponse(true, $data);

        case 'shiftRequests':
            $stmt = $pdo->query("
                SELECT
                    sr.id,
                    sr.employee_id,
                    sr.requested_date,
                    sr.requested_shift,
                    sr.reason,
                    sr.status
                FROM shift_requests sr
                ORDER BY sr.created_at DESC, sr.id DESC
            ");

            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
            $data = [];

            foreach ($rows as $row) {
                $data[] = [
                    'id' => (int)$row['id'],
                    'employeeId' => (string)$row['employee_id'],
                    'requestedDate' => (string)$row['requested_date'],
                    'requestedShift' => (string)$row['requested_shift'],
                    'reason' => (string)($row['reason'] ?? ''),
                    'status' => ucfirst((string)$row['status'])
                ];
            }

            sharedResponse(true, $data);

        case 'schedules':
            $weekStart = date('Y-m-d', strtotime('monday this week'));
            $weekEnd = date('Y-m-d', strtotime('friday this week'));

            $stmt = $pdo->prepare("
                SELECT
                    s.employee_id,
                    s.schedule_date,
                    s.start_time,
                    s.end_time,
                    s.shift_name,
                    s.status
                FROM schedules s
                WHERE s.schedule_date BETWEEN :week_start AND :week_end
                  AND s.status <> 'cancelled'
                ORDER BY s.employee_id ASC, s.schedule_date ASC, s.id ASC
            ");

            $stmt->execute([
                ':week_start' => $weekStart,
                ':week_end' => $weekEnd
            ]);

            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
            $grouped = [];

            foreach ($rows as $row) {
                $employeeId = (string)$row['employee_id'];
                if (!isset($grouped[$employeeId])) {
                    $grouped[$employeeId] = [
                        'employeeId' => $employeeId,
                        'week' => date('M d', strtotime($weekStart)) . '-' .
                                  date('d, Y', strtotime($weekEnd)),
                        'mon' => '',
                        'tue' => '',
                        'wed' => '',
                        'thu' => '',
                        'fri' => ''
                    ];
                }

                $day = strtolower(date('D', strtotime((string)$row['schedule_date'])));
                $key = substr($day, 0, 3);

                $value =
                    substr((string)$row['start_time'], 0, 5) .
                    '-' .
                    substr((string)$row['end_time'], 0, 5);

                if (isset($grouped[$employeeId][$key])) {
                    $grouped[$employeeId][$key] = $value;
                }
            }

            sharedResponse(true, array_values($grouped));

        default:
            sharedResponse(true, [], 'No server-side mapping for this collection.');
    }

} catch (Throwable $e) {
    error_log('Shared data API error: ' . $e->getMessage());
    sharedResponse(false, null, 'Unable to load shared data.', 500);
}
