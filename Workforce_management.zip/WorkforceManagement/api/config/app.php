<?php
declare(strict_types=1);

// Use Philippine local time for all Workforce Management date/time operations.
date_default_timezone_set('Asia/Manila');

/*
 * Local XAMPP configuration.
 * Set 'local_mode' to false before production deployment.
 * In local mode, password authentication creates the PHP session
 * directly so the system works without Gmail SMTP.
 */
return [
    'local_mode' => true,
    'bypass_2fa_in_local' => true,
];
