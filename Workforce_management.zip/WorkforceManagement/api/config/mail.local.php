<?php
declare(strict_types=1);

/*
 * Optional local SMTP overrides.
 * Leave these blank for XAMPP demo mode.
 * For Gmail, use environment variables or a local file that is NOT shared.
 */
return [
    'host' => 'smtp.gmail.com',
    'port' => 587,
    'username' => '',
    'password' => '',
    'from_email' => '',
    'from_name' => 'Holiday Travelers Workforce Management'
];
