-- Workforce Management: repair an existing XAMPP database without dropping tables.
USE workforce_management;

-- Philippine local time.
SET time_zone = '+08:00';

-- Make sure the standard manager relationship exists.
UPDATE employees e
JOIN employees m ON m.employee_id = '26011002'
SET e.manager_id = m.id
WHERE e.employee_id IN ('26011003','26011004','26011005','26011006','26011007')
  AND (e.manager_id IS NULL OR e.manager_id <> m.id);

-- The default demo employee must start the day as NOT CLOCKED IN so Clock In is testable.
DELETE FROM attendance_records
WHERE employee_id = '26011003'
  AND attendance_date = CURDATE();

-- Refresh leave balances for the current year if a demo employee is missing a row.
INSERT INTO employee_leave_balances
    (employee_id, balance_year, vacation_days, sick_days, emergency_days)
SELECT e.employee_id, YEAR(CURDATE()), 15.00, 10.00, 5.00
FROM employees e
LEFT JOIN employee_leave_balances b
  ON b.employee_id = e.employee_id
 AND b.balance_year = YEAR(CURDATE())
WHERE b.id IS NULL
  AND e.employee_id <> '26011002';

-- Ensure database timestamps are aligned with Philippine time.
