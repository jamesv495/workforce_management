<?php
declare(strict_types=1);

require_once __DIR__ . '/api/auth/auth_helpers.php';

startWfmSession();

$user = $_SESSION['user'] ?? null;

if (is_array($user)) {
    $role = (string)($user['role'] ?? '');
    $pages = [
        'admin' => 'admin.php',
        'manager' => 'manager.php',
        'employee' => 'employee.php',
    ];

    header('Location: ' . ($pages[$role] ?? 'login.php'));
    exit;
}

header('Location: login.php');
exit;
